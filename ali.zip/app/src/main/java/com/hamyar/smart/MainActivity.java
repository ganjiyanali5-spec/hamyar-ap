package com.hamyar.smart;

import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.NetworkRequest;
import android.net.wifi.WifiConfiguration;
import android.net.wifi.WifiManager;
import android.net.wifi.WifiNetworkSpecifier;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.List;

public class MainActivity extends Activity {

    // ===== تنظیمات دستگاه =====
    private static final String WIFI_SSID = "همیار هوشمند";
    private static final String DEVICE_URL = "http://192.168.4.1";
    // ==========================

    private final Handler ui = new Handler(Looper.getMainLooper());
    private SharedPreferences prefs;
    private ConnectivityManager cm;
    private ConnectivityManager.NetworkCallback callback;
    private WebView web;
    private LinearLayout overlay;
    private TextView statusText;
    private Button retryBtn;
    private Button wifiPassBtn;
    private boolean connected = false;
    private boolean pageLoaded = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        if (Build.VERSION.SDK_INT >= 28) {
            getWindow().getAttributes().layoutInDisplayCutoutMode =
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
        }
        prefs = getSharedPreferences("hamyar", MODE_PRIVATE);
        cm = (ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE);

        buildUi();

        if (!prefs.contains("wifi_pass")) {
            askWifiPassword(false);
        } else {
            connect();
        }
    }

    // ---------- رابط کاربری ----------
    @SuppressLint("SetJavaScriptEnabled")
    private void buildUi() {
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);

        web = new WebView(this);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        s.setCacheMode(WebSettings.LOAD_NO_CACHE);
        s.setMediaPlaybackRequiresUserGesture(false);
        web.setBackgroundColor(Color.BLACK);
        web.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageStarted(WebView v, String url, Bitmap favicon) {
                pageLoaded = false;
            }

            @Override
            public void onPageFinished(WebView v, String url) {
                if (connected && !"about:blank".equals(url)) {
                    pageLoaded = true;
                    overlay.setVisibility(View.GONE);
                }
            }

            @TargetApi(23)
            @Override
            public void onReceivedError(WebView v, WebResourceRequest r, WebResourceError e) {
                if (r.isForMainFrame()) pageFailed();
            }

            @SuppressWarnings("deprecation")
            @Override
            public void onReceivedError(WebView v, int code, String desc, String url) {
                if (Build.VERSION.SDK_INT < 23) pageFailed();
            }
        });
        root.addView(web, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        overlay = new LinearLayout(this);
        overlay.setOrientation(LinearLayout.VERTICAL);
        overlay.setGravity(Gravity.CENTER);
        overlay.setBackgroundColor(0xFF10151C);
        overlay.setPadding(48, 48, 48, 48);

        TextView title = new TextView(this);
        title.setText("همیار هوشمند");
        title.setTextColor(Color.WHITE);
        title.setTextSize(28);
        title.setGravity(Gravity.CENTER);
        overlay.addView(title);

        statusText = new TextView(this);
        statusText.setTextColor(0xFFB8C4D4);
        statusText.setTextSize(16);
        statusText.setGravity(Gravity.CENTER);
        statusText.setPadding(0, 32, 0, 32);
        overlay.addView(statusText);

        retryBtn = new Button(this);
        retryBtn.setText("تلاش دوباره");
        retryBtn.setOnClickListener(v -> connect());
        overlay.addView(retryBtn);

        wifiPassBtn = new Button(this);
        wifiPassBtn.setText("تغییر رمز وای‌فای");
        wifiPassBtn.setOnClickListener(v -> askWifiPassword(true));
        overlay.addView(wifiPassBtn);

        root.addView(overlay, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        setContentView(root);
    }

    private void showStatus(String msg, boolean showButtons) {
        overlay.setVisibility(View.VISIBLE);
        statusText.setText(msg);
        int vis = showButtons ? View.VISIBLE : View.GONE;
        retryBtn.setVisibility(vis);
        wifiPassBtn.setVisibility(vis);
    }

    private void askWifiPassword(boolean cancelable) {
        final EditText input = new EditText(this);
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);
        input.setText(prefs.getString("wifi_pass", ""));
        input.setHint("رمز وای‌فای");
        input.setGravity(Gravity.CENTER);

        AlertDialog.Builder b = new AlertDialog.Builder(this)
                .setTitle("رمز وای‌فای همیار هوشمند")
                .setMessage("رمز در صفحه تنظیمات وای‌فای دستگاه نمایش داده می‌شود. فقط یک بار ذخیره می‌شود.")
                .setView(input)
                .setCancelable(cancelable)
                .setPositiveButton("اتصال", (d, w) -> {
                    prefs.edit().putString("wifi_pass", input.getText().toString().trim()).apply();
                    connect();
                });
        if (cancelable) b.setNegativeButton("لغو", null);
        b.show();
    }

    // ---------- اتصال به وای‌فای ----------
    private void releaseNetwork() {
        ui.removeCallbacksAndMessages(null);
        if (callback != null) {
            try { cm.unregisterNetworkCallback(callback); } catch (Exception ignored) { }
            callback = null;
        }
        bind(null);
        connected = false;
    }

    @SuppressWarnings("deprecation")
    private void bind(Network n) {
        try {
            if (Build.VERSION.SDK_INT >= 23) cm.bindProcessToNetwork(n);
            else ConnectivityManager.setProcessDefaultNetwork(n);
        } catch (Exception ignored) { }
    }

    @SuppressWarnings("deprecation")
    private void connect() {
        releaseNetwork();
        showStatus("در حال اتصال به وای‌فای «" + WIFI_SSID + "» …", false);
        final String pass = prefs.getString("wifi_pass", "");

        callback = new ConnectivityManager.NetworkCallback() {
            @Override
            public void onAvailable(Network network) {
                bind(network);
                connected = true;
                ui.post(() -> {
                    showStatus("در حال باز کردن همیار هوشمند …", false);
                    web.loadUrl(DEVICE_URL);
                });
            }

            @Override
            public void onUnavailable() {
                ui.post(() -> showStatus("اتصال به وای‌فای برقرار نشد.\nمطمئن شوید دستگاه روشن و وای‌فای آن فعال است و رمز درست است.", true));
            }

            @Override
            public void onLost(Network network) {
                connected = false;
                ui.post(() -> {
                    web.loadUrl("about:blank");
                    showStatus("ارتباط با دستگاه قطع شد.", true);
                });
            }
        };

        NetworkRequest.Builder rb = new NetworkRequest.Builder()
                .addTransportType(NetworkCapabilities.TRANSPORT_WIFI);

        if (Build.VERSION.SDK_INT >= 29) {
            WifiNetworkSpecifier.Builder sb = new WifiNetworkSpecifier.Builder().setSsid(WIFI_SSID);
            if (!pass.isEmpty()) sb.setWpa2Passphrase(pass);
            rb.removeCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET);
            rb.setNetworkSpecifier(sb.build());
            cm.requestNetwork(rb.build(), callback, 60000);
        } else {
            connectLegacy(pass);
            cm.requestNetwork(rb.build(), callback);
            ui.postDelayed(() -> {
                if (!connected) {
                    showStatus("اتصال به وای‌فای برقرار نشد.\nمطمئن شوید دستگاه روشن و وای‌فای آن فعال است و رمز درست است.", true);
                }
            }, 30000);
        }
    }

    // اندروید ۹ و پایین‌تر
    @SuppressWarnings({"deprecation", "ConstantConditions"})
    private void connectLegacy(String pass) {
        try {
            WifiManager wm = (WifiManager) getApplicationContext().getSystemService(WIFI_SERVICE);
            if (!wm.isWifiEnabled()) wm.setWifiEnabled(true);
            String quoted = "\"" + WIFI_SSID + "\"";

            List<WifiConfiguration> old = wm.getConfiguredNetworks();
            if (old != null) {
                for (WifiConfiguration c : old) {
                    if (quoted.equals(c.SSID)) wm.removeNetwork(c.networkId);
                }
            }

            WifiConfiguration conf = new WifiConfiguration();
            conf.SSID = quoted;
            if (pass.isEmpty()) {
                conf.allowedKeyManagement.set(WifiConfiguration.KeyMgmt.NONE);
            } else {
                conf.preSharedKey = "\"" + pass + "\"";
            }
            int id = wm.addNetwork(conf);
            if (id != -1) {
                wm.disconnect();
                wm.enableNetwork(id, true);
                wm.reconnect();
            }
        } catch (Exception ignored) { }
    }

    // ---------- خطای بارگذاری صفحه ----------
    private void pageFailed() {
        if (!connected) return;
        showStatus("دستگاه پاسخ نمی‌دهد. تلاش مجدد …", true);
        ui.removeCallbacksAndMessages(null);
        ui.postDelayed(() -> {
            if (connected && !pageLoaded) web.loadUrl(DEVICE_URL);
        }, 3000);
    }

    // ---------- تمام‌صفحه ----------
    @SuppressWarnings("deprecation")
    private void goImmersive() {
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) goImmersive();
    }

    @Override
    public void onBackPressed() {
        if (web.canGoBack()) web.goBack();
        // عمداً خروج نمی‌کند تا اشتباهی بسته نشود
    }

    @Override
    protected void onDestroy() {
        releaseNetwork();
        web.destroy();
        super.onDestroy();
    }
}
